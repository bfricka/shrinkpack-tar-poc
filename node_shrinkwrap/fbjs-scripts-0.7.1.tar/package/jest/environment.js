require('core-js/es6');

global.__DEV__ = true;
