2.0.0 / 2015-05-08
==================

  * Use global `Promise` when returning a promise

1.1.0 / 2015-02-01
==================

  * Use `crypto.randomBytes`, if available
  * deps: base64-url@1.2.1

1.0.3 / 2015-01-31
==================

  * Fix error branch that would throw
  * deps: base64-url@1.2.0

1.0.2 / 2015-01-08
==================

  * Remove dependency on `mz`

1.0.1 / 2014-06-18
==================

  * Remove direct `bluebird` dependency

1.0.0 / 2014-06-18
==================

  * Initial release
