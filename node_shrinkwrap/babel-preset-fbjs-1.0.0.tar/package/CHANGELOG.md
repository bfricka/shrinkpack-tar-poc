## [Unreleased]


## [1.0.0] - 2016-04-28

### Added
- Initial release as a separate module.
