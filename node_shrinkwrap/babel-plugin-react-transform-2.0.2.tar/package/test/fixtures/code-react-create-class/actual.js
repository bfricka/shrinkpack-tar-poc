const Foo = React.createClass({
  displayName: 'Foo'
});

React.createClass({
});
