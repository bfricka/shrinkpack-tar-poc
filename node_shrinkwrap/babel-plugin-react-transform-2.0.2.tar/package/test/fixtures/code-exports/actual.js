export default class Foo extends React.Component {}
export default class extends React.Component {}
export default React.createClass({});
export class Bar extends React.Component {}
export const bar = React.createClass({});
export default class Baz { render() {} }
export default class { render() {} }
export class Boo { render() {} }
