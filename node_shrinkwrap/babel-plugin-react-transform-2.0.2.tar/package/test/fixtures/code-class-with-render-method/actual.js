class Foo {
  render() {}
}
