const Foo = createClass({
  displayName: 'Foo'
});

const Bar = factory({
  displayName: 'Bar'
});
