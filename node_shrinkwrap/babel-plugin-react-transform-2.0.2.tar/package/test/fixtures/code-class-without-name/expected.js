const Foo = class extends React.Component {};
