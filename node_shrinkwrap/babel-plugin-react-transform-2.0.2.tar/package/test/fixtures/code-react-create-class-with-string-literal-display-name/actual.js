const MyComponent = React.createClass({
  displayName: 'my-component'
});
