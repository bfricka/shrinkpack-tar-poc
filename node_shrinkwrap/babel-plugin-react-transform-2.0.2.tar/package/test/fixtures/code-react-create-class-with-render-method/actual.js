const Foo = React.createClass({
  displayName: 'Foo',
  render: function () {}
});

React.createClass({
  render: function () {}
});

const Bar = React.createClass({
  render: function () {}
});
