const Foo = React.createClass({});
