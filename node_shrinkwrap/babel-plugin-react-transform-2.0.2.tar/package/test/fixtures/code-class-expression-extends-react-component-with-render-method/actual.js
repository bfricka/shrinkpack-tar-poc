foo(class Foo extends React.Component {
  render() {}
});
foo(class extends React.Component {
  render() {}
});
