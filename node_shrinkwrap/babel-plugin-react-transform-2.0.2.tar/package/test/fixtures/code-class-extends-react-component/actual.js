class Foo extends React.Component {}
