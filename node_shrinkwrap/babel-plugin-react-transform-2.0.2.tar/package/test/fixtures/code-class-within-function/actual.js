function factory() {
  return class Foo extends React.Component {}
}
