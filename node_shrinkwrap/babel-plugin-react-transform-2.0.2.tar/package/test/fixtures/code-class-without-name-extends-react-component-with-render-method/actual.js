const Foo = class extends React.Component {
  render() {}
}
