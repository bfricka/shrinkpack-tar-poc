const Foo = createClass({
  displayName: 'Foo',
  render: function () {}
});

const Bar = factory({
  displayName: 'Bar',
  render: function () {}
});
