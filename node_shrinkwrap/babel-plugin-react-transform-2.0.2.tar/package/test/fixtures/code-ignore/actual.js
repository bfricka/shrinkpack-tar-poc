import React from 'react';

const First = React.createNotClass({
  displayName: 'First'
});

class Second extends React.NotComponent {}
