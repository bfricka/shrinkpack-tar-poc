const Foo = React.createClass({
  displayName: Math.random()
});
