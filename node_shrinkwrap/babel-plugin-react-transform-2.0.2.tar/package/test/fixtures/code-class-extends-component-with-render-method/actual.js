import React, { Component } from 'react';
class Foo extends Component {
  render() {}
}
