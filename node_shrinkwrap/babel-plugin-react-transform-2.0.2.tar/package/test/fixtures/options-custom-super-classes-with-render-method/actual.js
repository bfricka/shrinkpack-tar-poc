class Foo extends BooComponent {
  render() {}
}
class Bar extends CustomComponent {
  render() {}
}
