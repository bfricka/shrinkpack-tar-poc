class Foo extends BooComponent {}
class Bar extends CustomComponent {}
