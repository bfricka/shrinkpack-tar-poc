0.1.0 / 2015-07-01
==================

  * Re-emit events with all original arguments
  * Refactor internals
  * perf: enable strict mode

0.0.1 / 2010-01-03
==================

  * Initial release
