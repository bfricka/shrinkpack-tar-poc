module.exports = function sign(number) {
	return number >= 0 ? 1 : -1;
};
